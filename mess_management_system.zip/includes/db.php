<?php
$conn = new mysqli("localhost", "your_user", "your_password", "mess_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>