<?php
session_start();
include 'includes/db.php';
if ($_SESSION['role'] !== 'admin') {
  echo "Access Denied";
  exit();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $expense_date = $_POST['expense_date'];
    $description = $_POST['description'];
    $amount = $_POST['amount'];
    $stmt = $conn->prepare("INSERT INTO expenses (expense_date, description, amount) VALUES (?, ?, ?)");
    $stmt->bind_param("ssd", $expense_date, $description, $amount);
    $stmt->execute();
    echo "Expense added successfully!";
}
?>
<form method="POST" action="add_expense.php">
  <input type="date" name="expense_date" required>
  <input type="text" name="description" required placeholder="Description">
  <input type="number" step="0.01" name="amount" required placeholder="Amount">
  <button type="submit">Add Expense</button>
</form>
